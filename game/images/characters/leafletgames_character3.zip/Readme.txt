Free Character Sprites made by Leaflet Games

These images may be used and modified freely.

Credit is not necessary.

Teela loves warm climates and hates being cold. She's proud of her body and flaunts it any chance she gets. She has a master's degree in geology but would rather lay on the beach than use her education.